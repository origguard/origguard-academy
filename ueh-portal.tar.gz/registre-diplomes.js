window.UEH_REGISTRE_DIPLOMES = [
  {
    "version": "OVP-1",
    "institution": "Université d'État d'Haïti (UEH)",
    "matricule": "UEH-FDSE-2026-0012",
    "etudiant": "Marie-Thérèse JEAN-BAPTISTE",
    "faculte": "Faculté de Droit et des Sciences Économiques (FDSE)",
    "diplome": "Licence en Droit",
    "mention": "Magna Cum Laude",
    "date_emission": "2026-07-15",
    "doc_sha256": "889e083505f4d0f2731ed5bb530625b38adb277e9c06755be761bd24b6d2c205",
    "merkle_root": "5177a210398821fff24b573e62f456395996a3b13980435ac1c9fdff0ba79654",
    "merkle_index": 0,
    "merkle_proof": [
      {
        "position": "right",
        "hash": "35d7f193d056db22168004824b0c11367e03c5c5fa2be717b6ae848fa0bb7269"
      },
      {
        "position": "right",
        "hash": "4acfa33ddae99d0265745a86aa2e97df069b150b2ee8122c896eefe3eede8cb7"
      }
    ],
    "ueh_signature_ed25519": "IBZnKIZUFQAsbQdhGEHwtQF4bWLRR/r8erWRfu7kwv4NWUuxOxvVRt7f0LdJvh1OmgC0D0doyxO4/Yi6MX86AQ==",
    "ueh_public_key_fingerprint": "7a02a81877ecc262",
    "verify_url_public": "https://app.origguard.com/ueh/verify.html?hash=889e083505f4d0f2731ed5bb530625b38adb277e9c06755be761bd24b6d2c205",
    "timestamp_utc": "2026-09-05T22:43:19.915Z",
    "ovp_seal": {
      "standard": "OVP-Seal (Cachet Électronique Visible CEV)",
      "issuer": "UEH-RECTORAT",
      "key_fingerprint": "7a02a81877ecc262",
      "nom_certifie": "JEAN-BAPTISTE",
      "prenom_certifie": "Marie-Thérèse",
      "faculte_sigle": "FDSE",
      "canonical_data": "OVP1:UEH-RECTORAT:7a02a81877ecc262:UEH-FDSE-2026-0012:JEAN-BAPTISTE:Marie-Thérèse:FDSE:Licence en Droit:Magna Cum Laude:2026-07-15:889e083505f4d0f2731ed5bb530625b38adb277e9c06755be761bd24b6d2c205",
      "signature_ed25519": "4yxTEKKuEny04_ZNsXWkrUH6HXziU5g7F3X1hzOL_bmr3FSycD2qC-JBAHOwXWxPhcfufHVBdL-rm4qeSMxxBA",
      "qr_payload": "https://app.origguard.com/ueh/verify.html?v=1&iss=UEH-RECTORAT&kid=7a02a81877ecc262&mat=UEH-FDSE-2026-0012&nom=JEAN-BAPTISTE&pre=Marie-Th%C3%A9r%C3%A8se&fac=FDSE&deg=Licence%20en%20Droit&men=Magna%20Cum%20Laude&dat=2026-07-15&sha=889e083505f4d0f2731ed5bb530625b38adb277e9c06755be761bd24b6d2c205&sig=4yxTEKKuEny04_ZNsXWkrUH6HXziU5g7F3X1hzOL_bmr3FSycD2qC-JBAHOwXWxPhcfufHVBdL-rm4qeSMxxBA#v=1&iss=UEH-RECTORAT&kid=7a02a81877ecc262&mat=UEH-FDSE-2026-0012&nom=JEAN-BAPTISTE&pre=Marie-Th%C3%A9r%C3%A8se&fac=FDSE&deg=Licence%20en%20Droit&men=Magna%20Cum%20Laude&dat=2026-07-15&sha=889e083505f4d0f2731ed5bb530625b38adb277e9c06755be761bd24b6d2c205&sig=4yxTEKKuEny04_ZNsXWkrUH6HXziU5g7F3X1hzOL_bmr3FSycD2qC-JBAHOwXWxPhcfufHVBdL-rm4qeSMxxBA"
    }
  },
  {
    "version": "OVP-1",
    "institution": "Université d'État d'Haïti (UEH)",
    "matricule": "UEH-FDS-2026-0045",
    "etudiant": "Alexandre AUGUSTIN",
    "faculte": "Faculté des Sciences (FDS)",
    "diplome": "Diplôme d'Ingénieur Civil (Génie Informatique)",
    "mention": "Summa Cum Laude",
    "date_emission": "2026-07-15",
    "doc_sha256": "35d7f193d056db22168004824b0c11367e03c5c5fa2be717b6ae848fa0bb7269",
    "merkle_root": "5177a210398821fff24b573e62f456395996a3b13980435ac1c9fdff0ba79654",
    "merkle_index": 1,
    "merkle_proof": [
      {
        "position": "left",
        "hash": "889e083505f4d0f2731ed5bb530625b38adb277e9c06755be761bd24b6d2c205"
      },
      {
        "position": "right",
        "hash": "4acfa33ddae99d0265745a86aa2e97df069b150b2ee8122c896eefe3eede8cb7"
      }
    ],
    "ueh_signature_ed25519": "IBZnKIZUFQAsbQdhGEHwtQF4bWLRR/r8erWRfu7kwv4NWUuxOxvVRt7f0LdJvh1OmgC0D0doyxO4/Yi6MX86AQ==",
    "ueh_public_key_fingerprint": "7a02a81877ecc262",
    "verify_url_public": "https://app.origguard.com/ueh/verify.html?hash=35d7f193d056db22168004824b0c11367e03c5c5fa2be717b6ae848fa0bb7269",
    "timestamp_utc": "2026-09-05T22:43:19.923Z",
    "ovp_seal": {
      "standard": "OVP-Seal (Cachet Électronique Visible CEV)",
      "issuer": "UEH-RECTORAT",
      "key_fingerprint": "7a02a81877ecc262",
      "nom_certifie": "AUGUSTIN",
      "prenom_certifie": "Alexandre",
      "faculte_sigle": "FDS",
      "canonical_data": "OVP1:UEH-RECTORAT:7a02a81877ecc262:UEH-FDS-2026-0045:AUGUSTIN:Alexandre:FDS:Diplôme d'Ingénieur Civil (Génie Informatique):Summa Cum Laude:2026-07-15:35d7f193d056db22168004824b0c11367e03c5c5fa2be717b6ae848fa0bb7269",
      "signature_ed25519": "oE7N0n5oYR9YtbqKwsj_BNwelvkxdLsK4_Y5vP6O0yL12wAWAlTNbu8NThYOLqs9q9TeOoEHUaXEY9JKjGH_DQ",
      "qr_payload": "https://app.origguard.com/ueh/verify.html?v=1&iss=UEH-RECTORAT&kid=7a02a81877ecc262&mat=UEH-FDS-2026-0045&nom=AUGUSTIN&pre=Alexandre&fac=FDS&deg=Dipl%C3%B4me%20d#v=1&iss=UEH-RECTORAT&kid=7a02a81877ecc262&mat=UEH-FDS-2026-0045&nom=AUGUSTIN&pre=Alexandre&fac=FDS&deg=Dipl%C3%B4me%20d'Ing%C3%A9nieur%20Civil%20(G%C3%A9nie%20Informatique)&men=Summa%20Cum%20Laude&dat=2026-07-15&sha=35d7f193d056db22168004824b0c11367e03c5c5fa2be717b6ae848fa0bb7269&sig=oE7N0n5oYR9YtbqKwsj_BNwelvkxdLsK4_Y5vP6O0yL12wAWAlTNbu8NThYOLqs9q9TeOoEHUaXEY9JKjGH_DQ"
    }
  },
  {
    "version": "OVP-1",
    "institution": "Université d'État d'Haïti (UEH)",
    "matricule": "UEH-FMP-2026-0008",
    "etudiant": "Dr. Nadine VALENTIN",
    "faculte": "Faculté de Médecine et de Pharmacie (FMP)",
    "diplome": "Doctorat en Médecine",
    "mention": "Très Honorable avec Félicitations du Jury",
    "date_emission": "2026-07-15",
    "doc_sha256": "63db72e6f1c5a53888998c9888f697870c085566c40263e15f8e9837b6082de4",
    "merkle_root": "5177a210398821fff24b573e62f456395996a3b13980435ac1c9fdff0ba79654",
    "merkle_index": 2,
    "merkle_proof": [
      {
        "position": "right",
        "hash": "23f6c775baf5650669ec49bec838e6243976f4f1ab6ba8fdb8adb3c152692668"
      },
      {
        "position": "left",
        "hash": "17365b9a13a8ec6e85855c40d8759de07603e105c1c33f73b55f6ff8335ce88f"
      }
    ],
    "ueh_signature_ed25519": "IBZnKIZUFQAsbQdhGEHwtQF4bWLRR/r8erWRfu7kwv4NWUuxOxvVRt7f0LdJvh1OmgC0D0doyxO4/Yi6MX86AQ==",
    "ueh_public_key_fingerprint": "7a02a81877ecc262",
    "verify_url_public": "https://app.origguard.com/ueh/verify.html?hash=63db72e6f1c5a53888998c9888f697870c085566c40263e15f8e9837b6082de4",
    "timestamp_utc": "2026-09-05T22:43:19.923Z",
    "ovp_seal": {
      "standard": "OVP-Seal (Cachet Électronique Visible CEV)",
      "issuer": "UEH-RECTORAT",
      "key_fingerprint": "7a02a81877ecc262",
      "nom_certifie": "VALENTIN",
      "prenom_certifie": "Dr. Nadine",
      "faculte_sigle": "FMP",
      "canonical_data": "OVP1:UEH-RECTORAT:7a02a81877ecc262:UEH-FMP-2026-0008:VALENTIN:Dr. Nadine:FMP:Doctorat en Médecine:Très Honorable avec Félicitations du Jury:2026-07-15:63db72e6f1c5a53888998c9888f697870c085566c40263e15f8e9837b6082de4",
      "signature_ed25519": "Ep0Pi_bBxzmFtTBCfEwgKNqoGXPDy8XNusindn4H-FP3hc_JBzU2T3pQwYsBIbz_V3s9nXOkZXO1xs4cU1GWAQ",
      "qr_payload": "https://app.origguard.com/ueh/verify.html?v=1&iss=UEH-RECTORAT&kid=7a02a81877ecc262&mat=UEH-FMP-2026-0008&nom=VALENTIN&pre=Dr.%20Nadine&fac=FMP&deg=Doctorat%20en%20M%C3%A9decine&men=Tr%C3%A8s%20Honorable%20avec%20F%C3%A9licitations%20du%20Jury&dat=2026-07-15&sha=63db72e6f1c5a53888998c9888f697870c085566c40263e15f8e9837b6082de4&sig=Ep0Pi_bBxzmFtTBCfEwgKNqoGXPDy8XNusindn4H-FP3hc_JBzU2T3pQwYsBIbz_V3s9nXOkZXO1xs4cU1GWAQ#v=1&iss=UEH-RECTORAT&kid=7a02a81877ecc262&mat=UEH-FMP-2026-0008&nom=VALENTIN&pre=Dr.%20Nadine&fac=FMP&deg=Doctorat%20en%20M%C3%A9decine&men=Tr%C3%A8s%20Honorable%20avec%20F%C3%A9licitations%20du%20Jury&dat=2026-07-15&sha=63db72e6f1c5a53888998c9888f697870c085566c40263e15f8e9837b6082de4&sig=Ep0Pi_bBxzmFtTBCfEwgKNqoGXPDy8XNusindn4H-FP3hc_JBzU2T3pQwYsBIbz_V3s9nXOkZXO1xs4cU1GWAQ"
    }
  },
  {
    "version": "OVP-1",
    "institution": "Université d'État d'Haïti (UEH)",
    "matricule": "UEH-FAMV-2026-0021",
    "etudiant": "Jean-Michel DORVAL",
    "faculte": "Faculté d'Agronomie et de Médecine Vétérinaire (FAMV)",
    "diplome": "Ingénieur-Agronome",
    "mention": "Cum Laude",
    "date_emission": "2026-07-15",
    "doc_sha256": "23f6c775baf5650669ec49bec838e6243976f4f1ab6ba8fdb8adb3c152692668",
    "merkle_root": "5177a210398821fff24b573e62f456395996a3b13980435ac1c9fdff0ba79654",
    "merkle_index": 3,
    "merkle_proof": [
      {
        "position": "left",
        "hash": "63db72e6f1c5a53888998c9888f697870c085566c40263e15f8e9837b6082de4"
      },
      {
        "position": "left",
        "hash": "17365b9a13a8ec6e85855c40d8759de07603e105c1c33f73b55f6ff8335ce88f"
      }
    ],
    "ueh_signature_ed25519": "IBZnKIZUFQAsbQdhGEHwtQF4bWLRR/r8erWRfu7kwv4NWUuxOxvVRt7f0LdJvh1OmgC0D0doyxO4/Yi6MX86AQ==",
    "ueh_public_key_fingerprint": "7a02a81877ecc262",
    "verify_url_public": "https://app.origguard.com/ueh/verify.html?hash=23f6c775baf5650669ec49bec838e6243976f4f1ab6ba8fdb8adb3c152692668",
    "timestamp_utc": "2026-09-05T22:43:19.923Z",
    "ovp_seal": {
      "standard": "OVP-Seal (Cachet Électronique Visible CEV)",
      "issuer": "UEH-RECTORAT",
      "key_fingerprint": "7a02a81877ecc262",
      "nom_certifie": "DORVAL",
      "prenom_certifie": "Jean-Michel",
      "faculte_sigle": "FAMV",
      "canonical_data": "OVP1:UEH-RECTORAT:7a02a81877ecc262:UEH-FAMV-2026-0021:DORVAL:Jean-Michel:FAMV:Ingénieur-Agronome:Cum Laude:2026-07-15:23f6c775baf5650669ec49bec838e6243976f4f1ab6ba8fdb8adb3c152692668",
      "signature_ed25519": "Da5LPvUFS6G2CKchJS8nlO_OlDvaMcXn_qQ8XTe9REk4eVCC_YzUlVxg97z2G8d0Sdp6Hx_5bXVYfcK7lwZwAA",
      "qr_payload": "https://app.origguard.com/ueh/verify.html?v=1&iss=UEH-RECTORAT&kid=7a02a81877ecc262&mat=UEH-FAMV-2026-0021&nom=DORVAL&pre=Jean-Michel&fac=FAMV&deg=Ing%C3%A9nieur-Agronome&men=Cum%20Laude&dat=2026-07-15&sha=23f6c775baf5650669ec49bec838e6243976f4f1ab6ba8fdb8adb3c152692668&sig=Da5LPvUFS6G2CKchJS8nlO_OlDvaMcXn_qQ8XTe9REk4eVCC_YzUlVxg97z2G8d0Sdp6Hx_5bXVYfcK7lwZwAA#v=1&iss=UEH-RECTORAT&kid=7a02a81877ecc262&mat=UEH-FAMV-2026-0021&nom=DORVAL&pre=Jean-Michel&fac=FAMV&deg=Ing%C3%A9nieur-Agronome&men=Cum%20Laude&dat=2026-07-15&sha=23f6c775baf5650669ec49bec838e6243976f4f1ab6ba8fdb8adb3c152692668&sig=Da5LPvUFS6G2CKchJS8nlO_OlDvaMcXn_qQ8XTe9REk4eVCC_YzUlVxg97z2G8d0Sdp6Hx_5bXVYfcK7lwZwAA"
    }
  }
];
